import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter5',
  templateUrl: './chapter5.page.html',
  styleUrls: ['./chapter5.page.scss'],
})
export class Chapter5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
