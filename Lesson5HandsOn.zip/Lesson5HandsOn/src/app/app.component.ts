import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  public appPages = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'Table of Contents',
      url: '/toc'
    },
    {
      title: 'Chatper 1 | The Beginning',
      url: '/chapter1'
    },
    {
      title: 'Chapter 2 | The C2',
      url: '/chapter2'
    },
    {
      title: 'Chapter 3 | The C3',
      url: '/chapter3'
    },
    {
      title: 'Chapter 4 | The C4',
      url: '/chapter4'
    },
    {
      title: 'Chapter 5 | The C5',
      url: '/chapter5'
    },
    {
      title: 'Chapter 6 | The C6',
      url: '/chapter6'
    },
    {
      title: 'Chapter 7 | The C7',
      url: '/chapter7'
    },
    {
      title: 'Chapter 8 | The C8',
      url: '/chapter8'
    }
    // {
    //   title: 'List',
    //   url: '/list',
    //   icon: 'list'
    // }
  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
