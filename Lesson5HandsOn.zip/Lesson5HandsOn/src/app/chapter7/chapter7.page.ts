import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter7',
  templateUrl: './chapter7.page.html',
  styleUrls: ['./chapter7.page.scss'],
})
export class Chapter7Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
