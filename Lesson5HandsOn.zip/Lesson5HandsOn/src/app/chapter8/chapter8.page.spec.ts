import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chapter8Page } from './chapter8.page';

describe('Chapter8Page', () => {
  let component: Chapter8Page;
  let fixture: ComponentFixture<Chapter8Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chapter8Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chapter8Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
