import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter8',
  templateUrl: './chapter8.page.html',
  styleUrls: ['./chapter8.page.scss'],
})
export class Chapter8Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
