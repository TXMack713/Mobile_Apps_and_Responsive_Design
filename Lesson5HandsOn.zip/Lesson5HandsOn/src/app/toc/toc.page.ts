import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toc',
  templateUrl: './toc.page.html',
  styleUrls: ['./toc.page.scss'],
})
export class TocPage implements OnInit {
  public chapters = [
    {
      title: 'Home',
      url: '/home'
    },
    {
      title: 'Table of Contents',
      url: '/toc'
    },
    {
      title: 'Chatper 1 | The Beginning',
      url: '/chapter1'
    },
    {
      title: 'Chapter 2 | The C2',
      url: '/chapter2'
    },
    {
      title: 'Chapter 3 | The C3',
      url: '/chapter3'
    },
    {
      title: 'Chapter 4 | The C4',
      url: '/chapter4'
    },
    {
      title: 'Chapter 5 | The C5',
      url: '/chapter5'
    },
    {
      title: 'Chapter 6 | The C6',
      url: '/chapter6'
    },
    {
      title: 'Chapter 7 | The C7',
      url: '/chapter7'
    },
    {
      title: 'Chapter 8 | The C8',
      url: '/chapter 8'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
